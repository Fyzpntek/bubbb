import fs from 'fs'

global.owner = ['62 898-7544-383'] // Ganti nomor kakak ya
global.ownerName = 'Leonhart'
global.botName = 'Authority System Of Leonhart'
global.sessionName = 'session'
global.prefa = ['.', '/', '!'] 

// --- API KEYS ---
global.zenitsu = 'znx' 
global.nexray = 'nexray'

global.mess = {
    wait: '[SYSTEM] Initializing process...',
    success: '[SYSTEM] Task execution complete.',
    error: '[SYSTEM] Execution failure detected.',
    admin: '[SECURITY] Admin clearance required.',
    botAdmin: '[SECURITY] Bot requires elevated permissions.',
    owner: '[ROOT ACCESS] Owner authentication needed.',
    group: '[ENVIRONMENT ERROR] Group session not detected.',
}

let file = import.meta.url
import.meta.poll = (file, cb) => {
    fs.watchFile(file, () => cb(file))
}
import.meta.poll(file, () => {
    console.log('Update di config.js!')
})