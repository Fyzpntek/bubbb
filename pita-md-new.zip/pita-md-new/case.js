import fs from 'fs'
import axios from 'axios'
import { exec } from 'child_process'
import * as Utils from './lib/myfunc.js'
import uploadImage from './lib/uploadImage.js'
import { toSticker } from './lib/converter.js'
import './config.js'

export const pitaaHandler = async (conn, m) => {
    try {
 
        const body = (m.message?.conversation || m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || m.message?.extendedTextMessage?.text || m.message?.buttonsResponseMessage?.selectedButtonId || '')
        const prefix = /^[\\/!#.]/gi.test(body) ? body.match(/^[\\/!#.]/gi)[0] : ''
        const isCmd = body.startsWith(prefix)
        const command = isCmd ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : ''
        const args = body.trim().split(/ +/).slice(1)
        const text = args.join(" ")
        const pushname = m.pushName || "LEONHART"
        const botNumber = await conn.decodeJid(conn.user.id)
        const sender = m.key.fromMe ? (conn.user.id.split(':')[0]+'@s.whatsapp.net' || conn.user.id) : (m.key.participant || m.key.remoteJid)
        const isOwner = global.owner.includes(sender.split('@')[0])
        
        const isGroup = m.key.remoteJid.endsWith('@g.us')
        const groupMetadata = isGroup ? await conn.groupMetadata(m.key.remoteJid) : ''
        const participants = isGroup ? await groupMetadata.participants : ''
        const groupAdmins = isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
        const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false
        const isAdmins = isGroup ? groupAdmins.includes(sender) : false

        m.reply = (teks) => {
            conn.sendMessage(m.key.remoteJid, { text: teks }, { quoted: m })
        }

        if (isCmd) {
            await conn.sendPresenceUpdate('composing', m.key.remoteJid)
        }

        if (isGroup && isBotAdmins && !isAdmins && !isOwner) {
            
            if (body.includes('chat.whatsapp.com')) {
                await conn.sendMessage(m.key.remoteJid, { delete: m.key })
                return m.reply('[SYSTEM NOTICE]\nUnauthorized link detected.\nContent has been filtered by moderation protocol.');
            }
         
            const badwords = ['anjing', 'babi', 'tolol', 'bangsat', 'memek', 'ngentot', 'peler', 'asulibing']
            if (badwords.some(word => body.toLowerCase().includes(word))) {
                await conn.sendMessage(m.key.remoteJid, { delete: m.key })
                return m.reply(`[CONTENT FILTER ACTIVE]
${pushname}: Message deleted.
Reason: Communication protocol violation.`);

            }

            if (m.key.id.startsWith('BAE5') && !m.key.fromMe) {
                await m.reply('❌ *BOT DETECTED*\nMForeign automation process detected Execution blocked.')
                return await conn.groupParticipantsUpdate(m.key.remoteJid, [sender], 'remove')
            }
            
            const adultWords = ['bokep', 'porn', 'vcs', 'hentai', 'xnxx']
            if (adultWords.some(word => body.toLowerCase().includes(word))) {
                await m.reply('⚠️ [MODERATION ALERT]\nAdult content detected.\nThis channel enforces strict content compliance.')
                return await conn.groupParticipantsUpdate(m.key.remoteJid, [sender], 'remove')
            }
        }

        if (!isCmd) return

        switch(command) {

            case 'menu': {
                let menuText = `
┌──────────────────────────────┐
│   AI CORE INTERFACE ONLINE   │
└──────────────────────────────┘

Hello, users.
System unit **LEONHART AI** is now active.

How may this system assist you today?

[ Ready for command input... ] 
             
╭──𖥔 *MAKER & CONVERTER*
│ꕤ ${prefix}iqc <teks>
│ꕤ ${prefix}brat <teks>
│ꕤ ${prefix}bratanime <teks>
│ꕤ ${prefix}fakestory <user|teks>
│ꕤ ${prefix}sticker (reply foto)
╰─────────────𖥔

╭──𖥔 *STALKER*
│ꕤ ${prefix}mlstalk <id|zone>
╰─────────────𖥔

╭──𖥔 *GROUP*
│ꕤ ${prefix}hidetag 
│ꕤ ${prefix}open 
│ꕤ ${prefix}close 
│ꕤ ${prefix}kick 
╰─────────────𖥔

╭──𖥔 *SECURITY SYSTEM*
│ꕤ Antilink: ✅ Active
│ꕤ Antibot: ✅ Active
│ꕤ Anti-18+: ✅ Active
│ꕤ Anti-Toxic: ✅ Active
╰─────────────𖥔
`
                await conn.sendMessage(m.key.remoteJid, { 
                    text: menuText,
                    contextInfo: { 
                        externalAdReply: { 
                            title: "𝗟𝗲𝗼𝗻𝗵𝗮𝗿𝘁 𝗔𝗜 - 𝗖𝗼𝗿𝗲 𝗦𝘆𝘀𝘁𝗲𝗺"
                            body"Submit any request to Leonhart AI."
                            previewType: "PHOTO", 
                            thumbnailUrl: "https://files.catbox.moe/m4xx76.jpeg",
                            sourceUrl: "https://github.com" 
                        } 
                    } 
                }, { quoted: m })
            }
            break

            case 'iqc': {
                if (!text) return m.reply('⚠️ Input required.\nExample: ${prefix}iqc Hello Leonhart AI')
                m.reply('[SYSTEM] Generating response...')
                try {
                    const { data } = await axios.get(`https://api.zenitsu.web.id/api/maker/iqc?text=${encodeURIComponent(text)}&apikey=${global.zenitsu}`, { responseType: 'arraybuffer' })
                    await conn.sendMessage(m.key.remoteJid, { image: data, caption: `*Leonhart AI has completed the operation."*` }, { quoted: m })
                } catch (e) { m.reply('Leonhart AI detected a fault in the IQC processing module.') }
            }
            break

            case 'brat': {
                if (!text) return m.reply('Leonhart AI requires textual data to render sticker output.')
                try {
                    let resUrl = `https://api.nexray.web.id/maker/brat?text=${encodeURIComponent(text)}`
                    let buffer = await Utils.getBuffer(resUrl)
                    await conn.sendMessage(m.key.remoteJid, { sticker: buffer }, { quoted: m })
                } catch (e) { m.reply('"Leonhart AI encountered a failure during sticker generation."') }
            }
            break

            case 'bratanime': {
                if (!text) return m.reply('Leonhart AI requires textual input to generate anime-style output.')
                try {
                    let resUrl = `https://api.nexray.web.id/maker/bratanime?text=${encodeURIComponent(text)}`
                    let buffer = await Utils.getBuffer(resUrl)
                    await conn.sendMessage(m.key.remoteJid, { sticker: buffer }, { quoted: m })
                } catch (e) { m.reply('Leonhart AI reports the anime generation module is temporarily inactive.') }
            }
            break

            case 'fakestory': {
                if (!text.includes('|')) return m.reply('Format: username|caption\nContoh: .fakestory LeonhartAI|SISTEM INTERNAL')
                let [u, c] = text.split('|')
                let avatar = "https%3A%2F%2Ffiles.catbox.moe%2Fj2kua7.jpg"
                let resUrl = `https://api.nexray.web.id/maker/fakestory?username=${encodeURIComponent(u)}&caption=${encodeURIComponent(c)}&avatar=${avatar}`
                await conn.sendMessage(m.key.remoteJid, { image: { url: resUrl }, caption: 'LEONHART AI HAS FINISHED THE PROCCES' }, { quoted: m })
            }
            break

            case 's':
            case 'sticker': {
                let q = m.quoted ? m.quoted : m
                let mime = (q.msg || q).mimetype || ''
                if (/image/.test(mime)) {
                    m.reply('Leonhart AI is rendering sticker output from the provided media.')
                    let media = await q.download()
                    let encmedia = await toSticker(media, 'jpg')
                    await conn.sendMessage(m.key.remoteJid, { sticker: encmedia }, { quoted: m })
                } else {
                    m.reply('Leonhart AI requires an image source to proceed with processing.')
                }
            }
            break

            case 'mlstalk': {
                if (!text) return m.reply(`Contoh: ${prefix}mlstalk 1001972742|13005`)
                let [id, zone] = text.split('|')
                if (!id || !zone) return m.reply('Mana ID sama Zone-nya kak?')
                m.reply('WAIT A MINUTE, LEONHART AI SEARCH A ACCOUNT')
                try {
                    let res = await axios.get(`https://api.nexray.web.id/stalker/mlbb?id=${id}&zone=${zone}`)
                    let hasil = `🎮 *MOBILE LEGENDS STALKER* 🎮\n\n👤 Nickname: ${res.data.userName || 'FINISH!'}\n🆔 ID: ${id}\n🌐 Zone: ${zone}\n\nLeonhart AI HAS FINISH`
                    m.reply(hasil)
                } catch (e) { m.reply('LEONHART AI HAS INTERNAL ERROR FROM API') }
            }
            break

            case 'hidetag': {
                if (!isGroup) return m.reply('Leonhart AI can execute this command only within a group channel.')
                if (!isAdmins) return m.reply('"Leonhart AI requires administrator authorization to execute global mention."')
                conn.sendMessage(m.key.remoteJid, { text: text ? text : '', mentions: participants.map(a => a.id) })
            }
            break

            case 'open': {
                if (!isGroup || !isBotAdmins || !isAdmins) return m.reply('Leonhart AI requires administrator privileges to proceed.')
                await conn.groupSettingUpdate(m.key.remoteJid, 'not_announcement')
                m.reply('Leonhart AI confirms the group channel is now open for interaction.')
            }
            break

            case 'close': {
                if (!isGroup || !isBotAdmins || !isAdmins) return m.reply('Leonhart AI requires administrator privileges to proceed.🥺')
                await conn.groupSettingUpdate(m.key.remoteJid, 'announcement')
                m.reply('"Leonhart AI has restricted message flow in this group."')
            }
            break

            case 'kick': {
                if (!isGroup || !isBotAdmins || !isAdmins) return m.reply('Leonhart AI requires elevated permissions to execute user removal protocol.')
                let user = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                if (!user) return m.reply('"Leonhart AI requires a tagged user to execute the removal protocol."')
                await conn.groupParticipantsUpdate(m.key.remoteJid, [user], 'remove')
                m.reply('Leonhart AI confirms the member has been removed from the channel.')
            }
            break

            default:
                if (isCmd && isOwner && body.startsWith('>')) {
                    try {
                        let evaled = await eval(text)
                        if (typeof evaled !== 'string') evaled = await import('util').then(v => v.format(evaled))
                        m.reply(evaled)
                    } catch (e) { m.reply(String(e)) }
                }
        }
    } catch (err) {
        console.log('Error di PitaaHandler: ', err)
    }
}